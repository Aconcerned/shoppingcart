@extends('layouts.master') 

@section('title')
 Shopping Cart
@endsection

@section('content')

<br></br>

<div class="row"> <!--  Esta es la tabla de los productos en si-->
 <div class="col-sm-6 col-md-4 columna">
   <div class="thumbnail">
    <center><img src="https://images-na.ssl-images-amazon.com/images/I/8134AkhQJgL.jpg" alt="El Señor de los Anillos" class="img-responsive"></center>
     <h3>LABEL</h3>

     <div class="caption">
       <p>Etizzle shiznit fo shizzle sizzle augue hendrerizzle accumsizzle. Gizzle izzle est. Vivamizzle hizzle dolor, sure vitae, yippiyo id, ultrices izzle, sheezy.</p>
       <div class="text-left price">$12</div>
       <div class="text-right"><a href="#" class="btn btn-primary pull-right" role="button">Añadir</a></div>
     </div>

    </div>
   </div>

   <div class="col-sm-6 col-md-4 columna">
   <div class="thumbnail">
    <center><img src="https://images-na.ssl-images-amazon.com/images/I/8134AkhQJgL.jpg" alt="El Señor de los Anillos" class="img-responsive"></center>
     <h3>LABEL</h3>

     <div class="caption">
       <p>Etizzle shiznit fo shizzle sizzle augue hendrerizzle accumsizzle. Gizzle izzle est. Vivamizzle hizzle dolor, sure vitae, yippiyo id, ultrices izzle, sheezy.</p>
       <div class="text-left price">$12</div>
       <div class="text-right"><a href="#" class="btn btn-primary pull-right" role="button">Añadir</a></div>
     </div>

    </div>
   </div>


   <div class="col-sm-6 col-md-4 columna">
   <div class="thumbnail">
    <center><img src="https://images-na.ssl-images-amazon.com/images/I/8134AkhQJgL.jpg" alt="El Señor de los Anillos" class="img-responsive"></center>
     <h3>LABEL</h3>

     <div class="caption">
       <p>Etizzle shiznit fo shizzle sizzle augue hendrerizzle accumsizzle. Gizzle izzle est. Vivamizzle hizzle dolor, sure vitae, yippiyo id, ultrices izzle, sheezy.</p>
       <div class="text-left price">$12</div>
       <div class="text-right"><a href="#" class="btn btn-primary pull-right" role="button">Añadir</a></div>
     </div>

    </div>
   </div>

   </div>
@endsection